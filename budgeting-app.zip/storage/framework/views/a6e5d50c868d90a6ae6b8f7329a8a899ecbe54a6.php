<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<table>
    <tr>
    <form action="/transactions" id="filter-form">
        <td>
            <small>From: </small><input type="number" step="0.01" name="filter-amount1" placeholder="" value="<?php echo e(request('filter-amount1')); ?>"/>
            <small>To: </small><input type="number" step="0.01" name="filter-amount2" placeholder="" value="<?php echo e(request('filter-amount2')); ?>"/>
        </td>
        <td>
            <small>From: </small><input type="date" name="filter-date1" placeholder="" value="<?php echo e(request('filter-date1')); ?>"/>
            <small>To: </small><input type="date" name="filter-date2" placeholder="" value="<?php echo e(request('filter-date2')); ?>"/>
        </td>
        <td>
            <small>Category: </small><input type="text" name="filter-category" placeholder="" value="<?php echo e(request('filter-category')); ?>"/>
        </td>
        <td>
            <small>Description: </small><input type="text" name="filter-description" placeholder="" value="<?php echo e(request('filter-description')); ?>"/>
        </td>
        <td>
            <button type="submit">
                Filter
            </button>
        </td>
    </form>
    </tr>

    <tr>
        <td>Amount</td>
        <td>Date</td>
        <td>Category</td>
        <td>Description</td>
    </tr>
<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($transaction->amount); ?></td>
        <td><?php echo e($transaction->date); ?></td>
        <td><?php echo e($transaction->category); ?></td>
        <td><?php echo e($transaction->description); ?></td>
        <td>
            <form method="POST" action="/transactions/<?php echo e($transaction->id); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button>-</button>
            </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr class="inputs">
        <form method="POST" action="/transactions/store" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <td>
            <input
                type="number"
                step="0.01"
                name="amount"
                value="<?php echo e(old('amount')); ?>"
            />
    
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>

        <td>
            <input
                type="date"
                name="date"
                value="<?php echo e(old('date')); ?>"
            />
    
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>

        <td>
            <select name="category">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option value="Other">Other</option>
            </select>

            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>

        <td>
            <input
                type="text"
                name="description"
                value="<?php echo e(old('description')); ?>"
            />
    
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>

        <td>
            <button>
            +
            </button>
        </td>

        </form>
    </tr>
</table>
<?php echo e($transactions->links()); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/transactions/transactions.blade.php ENDPATH**/ ?>