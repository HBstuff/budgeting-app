/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/views/components/layout.blade.php"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
