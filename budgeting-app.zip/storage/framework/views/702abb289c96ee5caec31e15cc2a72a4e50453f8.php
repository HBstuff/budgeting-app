<?php if(session()->has('message')): ?>
    <div class="flash-message" x-data="{show: true}" x-init="setTimeout(() => show = false, 3000)" x-show="show">
        <p>
            <?php echo e(session('message')); ?>

        </p>
    </div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/components/flash-message.blade.php ENDPATH**/ ?>