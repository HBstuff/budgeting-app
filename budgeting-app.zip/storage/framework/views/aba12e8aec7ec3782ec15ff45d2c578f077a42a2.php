<?php 
    $temp = $crypto->json();
    $tempArray = [$temp[312], $temp[314], $temp[413], $temp[423], $temp[445], $temp[428]];    
?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="mb-10">
    <h2 class="text-center text-3xl text-gray-600 font-light pb-3">LAST CLOSE PRICE</h2>
    <div class="flex">
    <?php $__currentLoopData = $tempArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crypto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="w-1/2 flex justify-center">
            <div class="w-full p-2 m-2 rounded-3xl border border-solid border-gray-300 bg-indigo-300">
                <table class="w-full">
                    <tr>
                        <td class="py-3 px-6">
                            <h2 class="text-center text-3xl text-white font-bold pb-3"><?php echo e(explode("TUSD",$crypto['symbol'])[0]); ?>

                            <?php echo e('$' . number_format((float) $crypto['prevClosePrice'], 2, '.', '')); ?></h2>
                        </td>
                    </tr> 
                </table>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="flex">

    <div class="w-1/2 flex justify-center">
        <div class="w-full p-2 m-2 rounded-3xl border border-solid border-gray-300">
            <h2 class="text-center text-3xl text-gray-600 font-light pb-3">LATEST NEWS</h2>
            <table class="w-full text-gray-600 text-sm font-light">
                <?php $__currentLoopData = $news['latest-news']->object()->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd:bg-white even:bg-sky-50 hover:bg-cyan-100">
                        <td class="py-3 px-6">
                            <a class="font-bold" href="<?php echo e($item->link); ?>"><h3><?php echo e($item->title); ?></h3></a>
                        </td>
                        <td>
                            <?php echo e($item->publisher); ?> <?php echo e(date('Y/m/d H:i:s', $item->providerPublishTime)); ?>

                        </td>
                    </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <div class="w-1/2 flex justify-center">
        <div class="w-full p-2 m-2 rounded-3xl border border-solid border-gray-300">
            <h2 class="text-center text-3xl text-gray-600 font-light pb-3">FINANCIAL NEWS</h2>
            <table class="w-full text-gray-600 text-sm font-light">
                <?php $__currentLoopData = $news['financial-news']->object()->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd:bg-white even:bg-sky-50 hover:bg-cyan-100">
                        <td class="py-3 px-6">
                            <a class="font-bold" href="<?php echo e($item->link); ?>"><h3><?php echo e($item->title); ?></h3></a>
                        </td>
                        <td>
                            <?php echo e($item->publisher); ?> <?php echo e(date('Y/m/d H:i:s', $item->providerPublishTime)); ?>

                        </td>
                    </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/news.blade.php ENDPATH**/ ?>