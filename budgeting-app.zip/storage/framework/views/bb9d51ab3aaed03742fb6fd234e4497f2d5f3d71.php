<form action="/transactions">
    <div>
        <input type="text" name="search" placeholder="Search..." value="<?php echo e(request('search')); ?>"/>
        <div>
            <button type="submit">
            Filter
            </button>
        </div>
    </div>
</form><?php /**PATH /var/www/html/resources/views/partials/_search.blade.php ENDPATH**/ ?>