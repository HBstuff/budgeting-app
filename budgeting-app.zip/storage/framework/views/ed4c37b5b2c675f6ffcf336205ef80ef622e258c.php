<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="news">
<div class="news-column">
<?php $__currentLoopData = $response['latest-news']->object()->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="article">
    <div class="article-image">
        <?php if(isset($item->thumbnail->resolutions)): ?>
            <img src="<?php echo e($item->thumbnail->resolutions[1]->url); ?>">
        <?php else: ?>
            <img src="https://www.contentviewspro.com/wp-content/uploads/2017/07/default_image.png">
        <?php endif; ?>
    </div>

    
    <div class="article-content">
        <a class="article-link" href="<?php echo e($item->link); ?>"><h3><?php echo e($item->title); ?></h3></a>
        <?php echo e($item->publisher); ?>


        <?php echo e(date('Y/m/d H:i:s', $item->providerPublishTime)); ?>


    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="news-column">
    <?php $__currentLoopData = $response['financial-news']->object()->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="article">
        <div class="article-image">
            <?php if(isset($item->thumbnail->resolutions)): ?>
                <img src="<?php echo e($item->thumbnail->resolutions[1]->url); ?>">
            <?php else: ?>
                <img src="https://www.contentviewspro.com/wp-content/uploads/2017/07/default_image.png">
            <?php endif; ?>
        </div>
    
        <div class="article-content">
            <a class="article-link" href="<?php echo e($item->link); ?>"><h3><?php echo e($item->title); ?></h3></a>
            <?php echo e($item->publisher); ?>

    
            <?php echo e(date('Y/m/d H:i:s', $item->providerPublishTime)); ?>

    
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/news/index.blade.php ENDPATH**/ ?>