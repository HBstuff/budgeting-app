<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
        

        <script src="//unpkg.com/alpinejs" defer></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdn.tailwindcss.com"></script>

        <title>Budgeting App</title>
    </head>
    <body>
        <div class="flex font-custom">

            <?php if(auth()->guard()->check()): ?>
                <div class="max-w-2xl mx-auto w-1/5 h-screen bg-gray-800"></div>
                <?php echo $__env->make('partials._nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            
            <div class="w-full">
            <?php if(auth()->guard()->check()): ?>
                <?php echo $__env->make('partials._hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

                <main class="p-10">
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
        

        <?php echo $__env->make('partials._flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH /var/www/html/resources/views/components/layout.blade.php ENDPATH**/ ?>