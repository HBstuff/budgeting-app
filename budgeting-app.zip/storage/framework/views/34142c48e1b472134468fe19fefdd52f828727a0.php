<html>
    <head>

    </head>
    <body>
        <?php echo e($slot); ?>

    </body>
</html><?php /**PATH /var/www/html/resources/views/components/file.blade.php ENDPATH**/ ?>